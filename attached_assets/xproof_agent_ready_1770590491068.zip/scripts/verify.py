import json
import os

def verify_proof(file_path):
    with open(file_path, "r") as f:
        proof = json.load(f)
    if "id" in proof and "verified" in proof:
        return proof["verified"]
    return False

if __name__ == "__main__":
    for proof_file in os.listdir("../proofs"):
        if proof_file.endswith(".json"):
            result = verify_proof(f"../proofs/{proof_file}")
            print(f"{proof_file}: {'OK' if result else 'FAILED'}")
